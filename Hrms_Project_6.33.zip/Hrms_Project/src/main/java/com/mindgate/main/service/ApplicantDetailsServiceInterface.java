package com.mindgate.main.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.mindgate.main.domain.ApplicantDetails;

public interface ApplicantDetailsServiceInterface {

	public List<ApplicantDetails> ViewApplicant(int jobId);
	
	public boolean addNewApplicant(ApplicantDetails applicantDetails);

	public boolean updateApplicantStatus(ApplicantDetails applicantDetails);
	
	public ApplicantDetails getApplicant(int applicantId);

}
