package com.mindgate.main.repository;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.mindgate.main.domain.ApplicantDetails;
import com.mindgate.main.domain.DocumentDetails;
import com.mindgate.main.domain.JobDescriptionDetails;

@Repository
public class ApplicantDetailsRepository implements ApplicantDetailsRepositoryInterface {

	private static final String GET_VIEW_APPLICANT = " select a.applicant_id,a.applicant_name,a.qualification,a.skill_1,a.skill_2,a.skill_3,a.contact,a.document_id,a.job_id,a.status from Applicant_details a , job_description_details b where a.Skill_1 = b.Skill_1 and a.skill_2 = b.skill_2 and a.Skill_3 =b.Skill_3 and b.job_id=?";
	private static final String ADD_NEW_APPLICANT = "insert into applicant_details values(applicant_id_sequence_series.NEXTVAL,?,?,?,?,?,?,?,?)";
	private static final String UPDATE_APPLICANT_STATUS="update applicant_details set status= ? where applicant_id in (select applicant_id from interviewer_details where status='Pass')";
	private static final String GET_APPLICANT=" select a.applicant_id,a.applicant_name,a.qualification,a.skill_1,a.skill_2,a.skill_3,a.contact,a.document_id,a.job_id,a.status from Applicant_details a , job_description_details b where a.Skill_1 = b.Skill_1 and a.skill_2 = b.skill_2 and a.Skill_3 =b.Skill_3 and a.job_id=b.job_id and a.applicant_id=?";

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public List<ApplicantDetails> ViewApplicant(int jobId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.query(GET_VIEW_APPLICANT, new ApplicantDetailsRowMapper(), jobId);
	}

	@Override
	public boolean addNewApplicant(ApplicantDetails applicantDetails) {
		Object[] params = { applicantDetails.getApplicantName(), applicantDetails.getQualification(),
				applicantDetails.getSkill1(), applicantDetails.getSkill2(), applicantDetails.getSkill3(),
				applicantDetails.getContact(), applicantDetails.getDocumentDetails().getDocumentId(),
				applicantDetails.getJobDescriptionDetails().getJobId(),applicantDetails.getStatus() };
		System.out.println(applicantDetails);
		int result = jdbcTemplate.update(ADD_NEW_APPLICANT, params);
		if (result > 0){
			System.out.println("insert success");
			return true;
		}
		return false;
	}

	@Override
	public boolean updateApplicantStatus(ApplicantDetails applicantDetails) {
		
		int result=jdbcTemplate.update(UPDATE_APPLICANT_STATUS,applicantDetails.getStatus());
		if (result > 0){
			System.out.println("update success");
			return true;
		}
		return false;
	}

	@Override
	public ApplicantDetails getApplicant(int applicantId) {
		// TODO Auto-generated method stub
		System.out.println("getApplicant");
		return jdbcTemplate.queryForObject(GET_APPLICANT, new ApplicantDetailsRowMapper(),applicantId);
	}

}
